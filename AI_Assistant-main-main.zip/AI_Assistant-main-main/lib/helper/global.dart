import 'package:flutter/material.dart';

//app name
const appName = 'Ai Assistant';

//media query to store size of device screen
late Size mq;


String apiKey ='API_KEY';

